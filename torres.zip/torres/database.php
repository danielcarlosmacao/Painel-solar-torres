<?php


// Configurações do banco de dados
$host = 'localhost';
$user = 'root';  // Substitua pelo seu usuário
$password = 'vertrigo';  // Substitua pela sua senha
$dbName = 'torre';  // Substitua pelo nome do seu banco de dados
$filename = $dbName . '_backup_' . date('Y-m-d_H-i-s') . '.sql';


if(isset($_POST['export'])){
// Caminho para salvar o arquivo temporário
$tempFile = sys_get_temp_dir() . '/' . $filename;

// Executa o comando mysqldump para exportar o banco de dados
exec("mysqldump --host=$host --user=$user --password=$password $dbName > $tempFile");

// Verifica se o arquivo foi gerado
if (file_exists($tempFile)) {
    // Define os cabeçalhos para download do arquivo
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . basename($tempFile) . '"');
    header('Content-Length: ' . filesize($tempFile));
    
    // Lê o arquivo e envia para o cliente
    readfile($tempFile);

    // Exclui o arquivo temporário após o envio
    unlink($tempFile);
    exit;
} else {
    echo "Erro ao gerar o backup do banco de dados.";
}
}

if(isset($_POST["import"])){

    // Verifica se o arquivo foi enviado corretamente
if (isset($_FILES['backup_file']) && $_FILES['backup_file']['error'] === UPLOAD_ERR_OK) {
    
    // Caminho temporário do arquivo carregado
    $fileTmpPath = $_FILES['backup_file']['tmp_name'];
    $fileName = $_FILES['backup_file']['name'];

    // Verifica se o arquivo tem a extensão correta
    $fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

    if ($fileExtension !== 'sql') {
        die("Erro: O arquivo deve ser um arquivo .sql.");
    }

    // Lê o conteúdo do arquivo SQL
    $sql = file_get_contents($fileTmpPath);

    // Conectar ao banco de dados
    $connection = new mysqli($host, $user, $password, $dbName);

    if ($connection->connect_error) {
        die("Erro na conexão com o banco de dados: " . $connection->connect_error);
    }

    // Divide o conteúdo SQL em instruções separadas por ponto e vírgula
    $queries = explode(';', $sql);
    
    // Executa as instruções SQL uma por uma
    foreach ($queries as $query) {
        $query = trim($query);
        if (!empty($query)) {
            if (!$connection->query($query)) {
                echo "Erro ao executar a query: " . $connection->error . "<br>";
            }
        }
    }

    // Fecha a conexão com o banco de dados
    $connection->close();

    echo "Backup importado com sucesso!  <meta http-equiv='refresh' content='2;url=/admin/addons/torres/opcoes.php'>";

    
} else {
    echo "Erro no upload do arquivo.";
}
}
?>
