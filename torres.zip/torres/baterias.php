<?php
// INCLUE FUNCOES DE ADDONS -----------------------------------------------------------------------
include('addons.class.php');

// INCLUE configuraçoes do addon -----------------------------------------------------------------------
include('config.php');

// VERIFICA SE O USUARIO ESTA LOGADO --------------------------------------------------------------
session_name('mka');
if (!isset($_SESSION)) session_start();
if (!isset($_SESSION['mka_logado']) && !isset($_SESSION['MKA_Logado'])) exit('Acesso negado... <a href="/admin/login.php">Fazer Login</a>');

//Permissao nessecaria para acessa o addon
$nivel_Acesso = $permissao_padrao;

//licenciamento addon
$licenca = "1235";

if($licenca == "1235"){
	//createTable();
}

//Buscas
$query_bateria = "SELECT * FROM volt_bateria WHERE removido IS NULL ORDER BY marca ASC, amperes ASC";
 $result_bateria = mysqli_query($link,$query_bateria);

 //cria torre

	$bateriapnome = $_POST['nome'];
	$bateriamarca = $_POST['marca'];
	$bateriaamperes = $_POST['amperes'];
	$iddelete = $_POST['bateria_delete'];
	$idatualizar = $_GET['equip_atualiza'];


 if (isset($_POST['cria_bateria'])) {

	$query_cria_bateria = "INSERT INTO volt_bateria(nome,marca,amperes) VALUES ('$bateriapnome','$bateriamarca','$bateriaamperes')";
	$cria_bateria  = mysqli_query($link,$query_cria_bateria);
	header("location: /admin/addons/torres/baterias.php");

 }
 if (isset($_POST['bateria_delete'])) {

	$hoje = date('Y-m-d');
	$query_cria_bateria = "UPDATE volt_bateria SET removido='$hoje' where id=$iddelete";
	$cria_bateria  = mysqli_query($link,$query_cria_bateria);
	header("location: /admin/addons/torres/baterias.php");

 }
 if (isset($_POST['bateria_up'])) {
	$bateriaupid = $_POST['bateria_up'];
	$bateriapnome = $_POST['nome'];
	$bateriamarca = $_POST['marca'];
	$bateriaamperes = $_POST['amperes'];

	$query_up_equip = "UPDATE volt_bateria SET nome='$bateriapnome', marca='$bateriamarca', amperes='$bateriaamperes'  where id=$bateriaupid";
	$up_equip  = mysqli_query($link,$query_up_equip);
	header("location: /admin/addons/torres/baterias.php");

 }


?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>MK-AUTH :: <?php echo $Manifest->{'name'}; ?></title>

	<link href="../../estilos/mk-auth.css" rel="stylesheet" type="text/css" />
	<link href="../../estilos/font-awesome.css" rel="stylesheet" type="text/css" />
	<link href="../../estilos/bi-icons.css" rel="stylesheet" type="text/css" />
	<link href="style.css" rel="stylesheet" type="text/css" />

	<script src="../../scripts/jquery.js"></script>
	<script src="../../scripts/mk-auth.js"></script>
    <script>
        function confirmarDel() {
            // Exibe uma caixa de confirmação
            var confirmacao = window.confirm("Você tem certeza que deseja Deletar essa Bateria?");
            // Se o usuário clicar em "OK", o formulário será enviado
            if (confirmacao) {
                return true;
            } else {
                return false;  // Se o usuário clicar em "Cancelar", o formulário não será enviado
            }
        }
    </script>
</head>
<body>


	<div class="topo">
		<?php include('../../topo.php'); ?>
	</div>
<?php if(permicao($nivel_Acesso) == true):?>

	<div class="containermain">
		 <nav class="breadcrumb has-bullet-separator is-centered" aria-label="breadcrumbs">
            <ul>
                <li><a href="/admin/addons/torres"> ADDON</a></li>
                <li class="is-active">
                <a href="#" aria-current="page"> <?php echo htmlspecialchars($Manifest->{'name'} . " - V " . $Manifest->{'version'}); ?> </a>
                </li>

				<li>
				<button id="btn_form"  class="admin"><img src="img/mais.png" width="30px" height="30px"/></button>
				</li>
            </ul>
        </nav>
		<div>

		<div>
			<form id="my_form" action="/admin/addons/torres/baterias.php" method="post">

				<label>Nome:</label>
				<input type="text" name="nome" VALUES="null"/>
				<label>Marca:</label>
				<input type="text" name="marca" VALUES="null"/>
				<label>Amperes:</label>
				<input type="number" name="amperes"/>
				<input type="submit" class="salvar" name="cria_bateria" />
			</form>
		</div>

		<table id="table1">
			<thead>
				<tr>
					<th>Nome</th>
					<th>Marca</th>
					<th>Ah</th>
					<th style=" width: 200px;"></th>

				</tr>
			</thead>
			<tbody>
			<?php while ($row = mysqli_fetch_assoc( $result_bateria )) : ?>
				<tr>
				<?php
					$id = $row['id'];

				?>
				<form method="post">
					<!-- -->
					<td><?php if($idatualizar == $id){echo "<input name='nome' value=".$row['nome'].">";}else{echo "<a href='/admin/addons/torres/resumobateria.php?bat=$id'>" . $row['nome'] ."</a>";};?></td>
					<!-- -->
					<td><?php if($idatualizar == $id){echo "<input name='marca' value=".$row['marca'].">";}else{echo $row['marca'];};?></td>
					<!-- -->
					<td><?php if($idatualizar == $id){echo "<input name='amperes' value=".$row['amperes'].">";}else{echo $row['amperes'];};?></td>

					<!-- -->
					<td>
					<div class="grid-container-button">
					<button type="submit" name="bateria_up" <?php if($idatualizar != $id){echo "style='display: none;'";}?> value="<?php echo $id;?>"><img src="img/ok.png" width="30px" height="30px"/></button>
					</form>
					<div class="grid-container-button">
					<form method="get">
						<button type="submit" name="equip_atualiza" <?php if($idatualizar == $id){echo "style='display: none;'";}?> value="<?php echo $id;?>"  id="admin"><img src="img/atualizar.png" width="30px" height="30px"/></button>
					</form>
					<form method="post"  onsubmit="return confirmarDel();">
						<button type="submit" name="bateria_delete" <?php if($idatualizar == $id){echo "style='display: none;'";}?> value="<?php echo $id;?>"  id="admin"><img src="img/lixeira.png" width="30px" height="30px"/></button>
					</form>
						<a href="/admin/addons/torres/baterias.php">
							<button <?php if($idatualizar != $id){echo "style='display: none;'";}?> value="<?php echo $id;?>"><img src="img/x.png" width="30px" height="30px"/></button>
						</a>
					</div>
					</div>
					</td>
				</tr>
			<?php endwhile;?>
			</tbody>

		</table>


	</div>
<?php else : ?>
    <p class="no-data">Acesso não permitido!</p>
<?php endif; ?>
 	<?php include('../../baixo.php'); ?>
    <script src="../../menu.js.php"></script>
    <?php include('../../rodape.php'); ?>

<script>
var btn = document.getElementById('btn_form');
var form = document.getElementById('my_form');

btn.addEventListener('click', function() {
  if(form.style.display != 'block') {
    form.style.display = 'block';
    return;
  }
  form.style.display = 'none';
});
</script>
</body>
</html>
