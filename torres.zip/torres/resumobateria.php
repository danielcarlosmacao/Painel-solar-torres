<?php
// INCLUE FUNCOES DE ADDONS -----------------------------------------------------------------------
include('addons.class.php');

// INCLUE configuraçoes do addon -----------------------------------------------------------------------
include('config.php');

// VERIFICA SE O USUARIO ESTA LOGADO --------------------------------------------------------------
session_name('mka');
if (!isset($_SESSION)) session_start();
if (!isset($_SESSION['mka_logado']) && !isset($_SESSION['MKA_Logado'])) exit('Acesso negado... <a href="/admin/login.php">Fazer Login</a>');

//Permissao nessecaria para acessa o addon
$nivel_Acesso = $permissao_padrao;


//Buscas

$hoje= new DateTime(date());


$query_user = "SELECT * FROM volt_user WHERE removido IS NULL ORDER BY 'usuario' ASC";
$result_user = mysqli_query($link,$query_user);


$bateria = $_GET['bat'];
$query_armazenamento = "select vt.nome, vt.voltagem, va.id_torre, 
va.info, va.id_bateria, va.quantidade, va.data_instalacao, va.data_remocao, va.ativo, va.percentualproducao, vb.marca, vb.amperes 
from volt_armazenamento va join volt_torre vt join volt_bateria vb 
WHERE vt.id = id_torre AND  vb.id = va.id_bateria AND va.removido IS NULL AND  id_bateria='$bateria'";

if($_GET['ativo'] == 'sim'){
 $query_armazenamento .= " AND va.ativo = 's'";
}
if($_GET['ativo'] == 'nao'){
 $query_armazenamento .= " AND va.ativo = 'n' AND data_remocao IS NOT NULL";
}


$query_armazenamento .= " ORDER BY vt.nome ASC;";
$result_armazenamento = mysqli_query($link,$query_armazenamento);

$diasproducao = 0;
$torresproducao =0;
while ($row = mysqli_fetch_assoc($result_armazenamento)){

    $torresproducao = ++$torresproducao;

    $data_remocao = new DateTime($row['data_remocao']);
    $data_instalacao = new DateTime($row['data_instalacao']);
        
        if($data_remocao == ""){
            $producao =  $hoje->diff($data_instalacao);
            $diasproducao = $diasproducao + $producao->days;

        }else{
            $producao = $data_remocao->diff($data_instalacao);
            $diasproducao = $diasproducao + $producao->days;
        }

        $infobat = " ". $row['marca'] . " " .  $row['amperes'] . " Ah";
}

$mediaproducao = ($diasproducao/$torresproducao)/365;

$result_armazenamento->data_seek(0);

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>MK-AUTH :: <?php echo $Manifest->{'name'}; ?></title>

	<link href="../../estilos/mk-auth.css" rel="stylesheet" type="text/css" />
	<link href="../../estilos/font-awesome.css" rel="stylesheet" type="text/css" />
	<link href="../../estilos/bi-icons.css" rel="stylesheet" type="text/css" />
	<link href="style.css" rel="stylesheet" type="text/css" />

	<script src="../../scripts/jquery.js"></script>
	<script src="../../scripts/mk-auth.js"></script>

</head>
<body>


	<div class="topo">
		<?php include('../../topo.php'); ?>
	</div>
<?php if(permicao($nivel_Acesso) == true):?>

<div class="containermain">
    <nav class="breadcrumb has-bullet-separator is-centered" aria-label="breadcrumbs">
            <ul>
                <li><a href="/admin/addons/torres/baterias.php"> ADDON</a></li>
                <li class="is-active">
                <a href="#" aria-current="page"> <?php echo htmlspecialchars($Manifest->{'name'} . " - V " . $Manifest->{'version'}); ?> </a>
                </li>
            </ul>
    </nav>
    <div class="form">
                <form method="get">
                    <input type="hidden" name="bat" value="<?php echo $bateria; ?>">
                    <label for="ativo">Em producao:</label>
                    <input type="radio" name="ativo" id="ativo" value="sim" <?php if($_GET['ativo'] == 'sim'){echo 'checked';}?> />
                    <label for="Sim">Sim</label>&nbsp;&nbsp;
                    <input type="radio" name="ativo" id="ativo" value="nao" <?php if($_GET['ativo'] == 'nao'){echo 'checked';}?> />
                    <label for="NAo">Nao</label>
                    <button type="submit" class="buscar" >Buscar</button>
                </form>
            </div>
            <div>
                <?php echo "Media de tempo em producao de " .  round($mediaproducao,2). " anos da bateria" . $infobat;?>
            </div>
    <table id="table1">
        <thead>
            <tr>
                <th style=" width: 25%;">Torre</th>
                <th style=" width: 5%;">V</th>
                <th style=" width: 5%;">Quant</th>
                <th style=" width: 20%;">Data Instalação</th>
                <th style=" width: 20%;">Data Remoção</th>
                <th style=" width: 25%;">Tempo em Produção</th>
                <th style=" width: 25%;">% Produção</th>

            </tr>
        </thead>
        <tbody>
        <?php while ($row = mysqli_fetch_assoc($result_armazenamento)) : ?>
            <tr style="<?php if($row['data_remocao'] != NULL){ echo 'color:#696969'; }else{ echo 'font-weight: bold;';}?>">
                <?php 
                $data_remocao = new DateTime($row['data_remocao']);
                $data_instalacao = new DateTime($row['data_instalacao']);
                    
                    if($data_remocao == ""){
                        $producao =  $hoje->diff($data_instalacao);

                    }else{
                        $producao = $data_remocao->diff($data_instalacao);
                    }
                 
                
                ?>
                <td><a href="/admin/addons/torres/torre.php?idtorre=<?php echo $row['id_torre'];?>"><?php echo $row['nome']; ?></a></td>
                <td><?php echo $row['voltagem']; ?></td>
                <td><?php echo $row['quantidade']; ?></td>
                <td><?php echo $data_instalacao->format('d-m-Y'); ?></td>
                <td><?php if($row['data_remocao'] != NULL){echo $data_remocao->format('d-m-Y'); }?></td>
                <td><?php echo $producao->y . " anos e " . $producao->m . " Meses";?></td>
                <td><?php echo $row['percentualproducao'];?></td>
            </tr>
        <?php endwhile; ?>
        <tboby>
    </table>





</div>
<?php else : ?>
    <p class="no-data">Acesso não permitido!</p>
<?php endif; ?>
 	<?php include('../../baixo.php'); ?>
    <script src="../../menu.js.php"></script>
    <?php include('../../rodape.php'); ?>


</body>
</html>
