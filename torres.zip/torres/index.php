<?php
// INCLUE FUNCOES DE ADDONS -----------------------------------------------------------------------
include('addons.class.php');

// INCLUE configuraçoes do addon -----------------------------------------------------------------------
include('config.php');

// VERIFICA SE O USUARIO ESTA LOGADO --------------------------------------------------------------
session_name('mka');
if (!isset($_SESSION)) session_start();
if (!isset($_SESSION['mka_logado']) && !isset($_SESSION['MKA_Logado'])) exit('Acesso negado... <a href="/admin/login.php">Fazer Login</a>');

//Permissao nessecaria para acessa o addon
$nivel_Acesso = $permissao_padrao;



//Buscas

// Número de registros por página
$registros_por_pagina = opcao("registro_pagina");
if(opcao("registro_pagina")==""){
    $registros_por_pagina = 20;
}
// Determinando a página atual
$pagina_atual = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
$inicio = ($pagina_atual - 1) * $registros_por_pagina;
// Contando o total de registros
$sql_total = "SELECT COUNT(*) FROM volt_torre WHERE removido IS NULL";
$result_total = $link->query($sql_total);
$row_total = $result_total->fetch_row();
$total_registros = $row_total[0];
// Cálculo do número total de páginas
$total_paginas = ceil($total_registros / $registros_por_pagina);



$query_torre = "SELECT * FROM volt_torre WHERE removido IS NULL ORDER BY nome ASC LIMIT $inicio, $registros_por_pagina"; 
if(isset($_GET['torre'])){
	$nometorre = $_GET['torre'];
	$query_torre .= " AND nome LIKE '%$nometorre%'";
}
if(isset($_GET['ordem'])){
	$ordem = $_GET['ordem'];
	$query_torre .= " ORDER BY nome $ordem";
}

$result_torre = mysqli_query($link,$query_torre);


//

$query__valida = mysqli_query($link, "SELECT * FROM volt_opcoes WHERE  removido IS NULL");
$valida = mysqli_num_rows($query__valida);

 //cria torre

	$trnome = $_POST['nome'];
	$trvoltagem = $_POST['voltagem'];

 if($trnome != null){
	$query_cria_torre = "INSERT INTO volt_torre (nome,voltagem) VALUES ('$trnome','$trvoltagem')";
	$cria_torre = mysqli_query($link,$query_cria_torre);
	header("location: /admin/addons/torres/");
 }

 if(isset($_POST['torre_delete'])){

	$id = $_POST['torre_delete'];
	$hoje = date('Y-m-d');
	$query_deleta_torre = "UPDATE volt_torre SET removido='$hoje' WHERE id='$id'";
	$deleta_torre = mysqli_query($link,$query_deleta_torre);
	header("location: /admin/addons/torres/");
 }

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>MK-AUTH :: <?php echo $Manifest->{'name'}; ?></title>

	<link href="../../estilos/mk-auth.css" rel="stylesheet" type="text/css" />
	<link href="../../estilos/font-awesome.css" rel="stylesheet" type="text/css" />
	<link href="../../estilos/bi-icons.css" rel="stylesheet" type="text/css" />
	<link href="style.css" rel="stylesheet" type="text/css" />

	<script src="../../scripts/jquery.js"></script>
	<script src="../../scripts/mk-auth.js"></script>
    <script>
        function confirmarEnvio() {
            // Exibe uma caixa de confirmação
            var confirmacao = window.prompt("Você tem certeza que deseja Deletar essa torre? digite sim");
            // Se o usuário clicar em "OK", o formulário será enviado
            if (confirmacao == 'sim') {
                return true;
            } else {
                return false;  // Se o usuário clicar em "Cancelar", o formulário não será enviado
            }
        }
    </script>

</head>
<body>


	<div class="topo">
		<?php include('../../topo.php'); ?>
	</div>
<?php if(permicao($nivel_Acesso) == true):?>

	<div class="containermain">
		 <nav class="breadcrumb has-bullet-separator is-centered" aria-label="breadcrumbs">
            <ul>
                <li><a href="/admin/addons/torres/"> ADDON</a></li>
                <li class="is-active">
                <a href="#" aria-current="page"> <?php echo htmlspecialchars($Manifest->{'name'} . " - V " . $Manifest->{'version'}); ?> </a>
                </li>

				<li>

				</li>
            </ul>
        </nav>
		<div>
            <?php ?>
		<center>
			<button id="btn_form" class="admin"><img src="img/mais.png" width="80px" height="80px"/></button>&nbsp;&nbsp;
			<button id="btn_form_busca"><img src="img/busca.png" width="80px" height="80px"/></button>&nbsp;&nbsp;
			<a href="/admin/addons/torres/equipamentos.php" ><img src="img/placa-de-circuito.png" width="100px" height="100px"/></a>&nbsp;&nbsp;
			<a href="/admin/addons/torres/baterias.php"><img src="img/bateria.png" width="100px" height="100px"/></a>&nbsp;&nbsp;
			<a href="/admin/addons/torres/placas.php"><img src="img/painel-solar.png" width="100px" height="100px"/></a>&nbsp;&nbsp;
			<a href="/admin/addons/torres/manutencaotorre.php"><img src="img/manutencao.png" width="80px" height="80px"/></a>&nbsp;&nbsp;
			<a href="/admin/addons/torres/opcoes.php" id="admin"><img src="img/engrenagem.png" width="80px" height="80px"/></a>&nbsp;&nbsp;
			<?php if($valida <=0):?><a href="/admin/addons/torres/registro.php"><img src="img/cadeado.png" width="80px" height="80px"/></a>&nbsp;&nbsp;<?php endif;?>
		</center>
		</div>
		<div class="containermaincenter" >
			<form id="form_busca" method="get" style="display:none" >
				<label for="torre">Torre:</label>
				<input type="text" style="width:40%" name="torre" value="<?php echo $_GET['torre'];?>"/>
				<label for="ordem">Ordem:</label>
				<select name="ordem" id="ordem">
					<option value="asc">A-Z</option>
					<option <?php if($_GET['ordem'] == "desc"){echo "selected"; };?> value="desc">Z-A</option>
				</select>
				<button class="buscar"   type="submit">Buscar</button>
			</form>
		</div>

		<div>
			<form id="my_form" action="/admin/addons/torres/" method="post">
				<label>Nome:</label>
				<input type="text" name="nome"  required/>
				<label>Voltagem:</label>
				<input type="number" id="voltagem" name="voltagem" pattern="^((12|24|36|48|60|72|84|96|108|120|\d{2,}12))$" required>
				<input type="submit" class="salvar" />
			</form>
		</div>

		<table id="table1">
			<thead>
				<tr>
					<th>Nome</th>
					<th>Voltagem</th>
					<th>Equipamentos</th>
					<th>Bateria</th>
					<th>Marca bateria</th>
					<th>Data Inst. bateria</th>
					<th>Placa</th>
					<th></th>

				</tr>
			</thead>
			<tbody>
			<?php while ($row = mysqli_fetch_assoc($result_torre)) : ?>
				<tr >
				<?php
					$id = $row['id'];
					$voltagemTorre = $row['voltagem'] ; 
					
					// busca Watts equipamentos

					$query_consumo = "SELECT vc.identificacao,vc.ativo,ve.nome,ve.watts FROM volt_consumo vc join volt_equipamento ve  WHERE  vc.id_equipamento = ve.id AND vc.ativo = 's' AND vc.removido IS NULL AND id_torre = '$id'";
					$result_consumo = mysqli_query($link,$query_consumo );
					$totalwattsequip = 0;

					while ($rowwatts = mysqli_fetch_assoc($result_consumo)){
						$totalwattsequip = $totalwattsequip + $rowwatts['watts'];
					}
				



					$query_bateria= "SELECT * FROM volt_armazenamento va join volt_bateria vb  WHERE id_torre = '$id' AND va.id_bateria = vb.id  AND data_remocao IS NULL AND ativo='s' AND va.removido IS NULL";
					$result_bateria = mysqli_query($link,$query_bateria );
					$row_bateria = mysqli_fetch_assoc($result_bateria);

					$query_placa = "SELECT * FROM volt_geracao vg join volt_placa vp  WHERE id_torre = '$id' AND vg.id_placa = vp.id  AND vg.removido IS NULL";
					$result_placa = mysqli_query($link,$query_placa );

					// faz contas relacionado a placa

					$amperes = 0;
					$watts = 0 ;
					while ($row_placa = mysqli_fetch_assoc($result_placa)){
						$amperes = $amperes + $row_placa['amperes'];
						$watts = $watts + $row_placa['watts'];
					}
					$PlacaAh = ((($totalwattsequip/$voltagemTorre)*24)/opcao(horas_geracao));
					
					$percentPlacaAh = ($PlacaAh/ $amperes*100);
					$percentPlacaW = (($PlacaAh*$voltagemTorre)/$watts)*100;

					$AhBateriaNessecaria = ($totalwattsequip/$voltagemTorre) * opcao(horas_autonomia);

					$totalbat = ($row_bateria['quantidade']*$row_bateria['amperes'])/($voltagemTorre/12);

					$percentbateriaAh = ($AhBateriaNessecaria/$totalbat)*100;

					if(is_nan($percentPlacaAh)){
						$percentPlacaAh = "";
					}
					if(is_nan($percentPlacaW)){
						$percentPlacaW = "";
					}

				?>
					<!-- -->
					<td><?php echo "<a href='/admin/addons/torres/torre.php?idtorre=$id'>" . $row['nome'] . "</a>"?></td>
					<!-- -->
					<td><?php echo $voltagemTorre;?></td>
					<!--  Equipamentos  -->
					<td><?php
						echo $result_consumo->num_rows . " Equip " . $totalwattsequip ." W ";
 					?></td>
					<!-- Bateria -->
					<td><?php
					if($result_bateria->num_rows == 1){
						echo $row_bateria['quantidade'] ." de ". $row_bateria['amperes'] . " Ah" . " - " . round($percentbateriaAh, 2)  .  " %";

						}else if ($result_bateria->num_rows >=2) {
							echo "Varias bateria ativa" ;
						}else{
							echo "Sem bateria" ;
						}
					?></td>
					<!-- Marca Bateria -->
					<td><?php
					if($result_bateria->num_rows == 1){
						echo $row_bateria['marca'];
						}else{
							echo "";
						}
					?></td>
					<!--data instalação -->
					<td><?php
					if($result_bateria->num_rows == 1){
						$dataHoje = date('d-m-Y');
						$datainstalacao = date('d-m-Y', strtotime($row_bateria['data_instalacao']));
						$datadif= ((strtotime($dataHoje)-strtotime($datainstalacao))/(60*60*24))/365;
						echo $datainstalacao . "&nbsp;&nbsp;&nbsp;&nbsp;";
						echo "<strong>" . round($datadif,2) ."</strong>";
						}else{
							echo "";
						}
					?></td>
					<!-- -->
					<td style="text-align: center;" ><?php
						echo $amperes . " Ah " . round($percentPlacaAh, 2) . " %" . "&nbsp;&nbsp;";
						echo " - &nbsp;&nbsp;" . $watts . " w " . round($percentPlacaW, 2) . " % ";
					?></td>
					<td>
						<form method="post" onsubmit="return confirmarEnvio();">
							<button name="torre_delete" type="submit" value="<?php echo $id;?>" id="admin"><img src="img/lixeira.png" width="20px" height="20px"/></button>
						</form>
					</td>
				</tr>
			<?php endwhile;?>
			</tbody>

		</table>
        <div Class="paginas">
            <?php 
            
             for ($i = 1; $i <= $total_paginas; $i++) {
                 if ($i == $pagina_atual) {
                     echo "<strong>$i</strong> ";
                 } else {
                     echo "<a href='?pagina=$i'>$i</a> ";
                 }
             }
           ?>
        </div>


	</div>
	

<?php elseif (acesso() == 'manutencao'): ?>

	<div class="containermain">
		 <nav class="breadcrumb has-bullet-separator is-centered" aria-label="breadcrumbs">
            <ul>
                <li><a href="#"> ADDON</a></li>
                <li class="is-active">
                <a href="#" aria-current="page"> <?php echo htmlspecialchars($Manifest->{'name'} . " - V " . $Manifest->{'version'}); ?> </a>
                </li>

				<li>

				</li>
            </ul>
        </nav>
		<div>
		<center>
			<a href="/admin/addons/torres/manutencaotorre.php"><img src="img/manutencao.png" width="80px" height="80px"/></a>&nbsp;&nbsp;
		</center>
		</div>

<?php else : ?>
    <p class="no-data">Acesso não permitido!</p>
<?php endif; ?>
 	<?php include('../../baixo.php'); ?>
    <script src="../../menu.js.php"></script>
    <?php include('../../rodape.php'); ?>




<script>

//exibe a adicao de torre 
var btn = document.getElementById('btn_form');
var form = document.getElementById('my_form');

btn.addEventListener('click', function() {
  if(form.style.display != 'block') {
    form.style.display = 'block';
    return;
  }
  form.style.display = 'none';
});

// Exibe a busca
var btnbusca = document.getElementById('btn_form_busca');
var formbusca = document.getElementById('form_busca');

btnbusca.addEventListener('click', function() {
  if(formbusca.style.display != 'block') {
    formbusca.style.display = 'block';
    return;
  }
  formbusca.style.display = 'none';
});


</script>
</body>
</html>
