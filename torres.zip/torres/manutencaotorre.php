<?php
// INCLUE FUNCOES DE ADDONS -----------------------------------------------------------------------
include('addons.class.php');

// INCLUE configuraçoes do addon -----------------------------------------------------------------------
include('config.php');

// VERIFICA SE O USUARIO ESTA LOGADO --------------------------------------------------------------
session_name('mka');
if (!isset($_SESSION)) session_start();
if (!isset($_SESSION['mka_logado']) && !isset($_SESSION['MKA_Logado'])) exit('Acesso negado... <a href="/admin/login.php">Fazer Login</a>');

//Permissao nessecaria para acessa o addon
$nivel_Acesso = $permissao_padrao;

$hoje = date('Y-m-d');
//Buscas

$query_torre = "SELECT * FROM volt_torre vt WHERE removido IS NULL ORDER BY nome ASC";
$result_torre = mysqli_query($link,$query_torre);



$query_manutencao = "SELECT vm.id, vm.id_torre, vm.informacao, vm.data_manutencao, vm.data_prox_manutencao, vm.cituacao, vm.removido, vt.nome FROM volt_manutencao vm join volt_torre vt ON vm.id_torre = vt.id  WHERE vm.removido IS NULL";

if(isset($_GET['busca'])){

if($_GET['torre'] != ""){
    $torre = $_GET['torre'];
    $query_manutencao .= " AND nome='$torre'";
}

if($_GET['cituacao'] != ""){
    if($_GET['cituacao'] != "Todos"){
        $cituacao = $_GET['cituacao'];
        $query_manutencao .= " AND cituacao='$cituacao'";
    }
}
}
if($_GET['cituacao'] ==""){
    $query_manutencao .= " AND cituacao != 'arquivado'";
}


 $query_manutencao .= " ORDER BY  nome ASC, data_manutencao ASC" ;





$result_manutencao = mysqli_query($link,$query_manutencao);

if(isset($_POST['cria_manutencao'])){
    $idtorre = $_POST['torre'];
    $informacao = $_POST['informacao'];
    $data_manutencao = $_POST['data_manutencao'];
    $data_prox_manutencao = $_POST['data_prox_manutencao'];
    $cituacao = $_POST['cituacao'];

    $query_cria_manutencao ="INSERT INTO volt_manutencao(id_torre,informacao,data_manutencao,data_prox_manutencao,cituacao) VALUE ('$idtorre','$informacao','$data_manutencao',' $data_prox_manutencao','$cituacao')";
	$cria_manutenca  = mysqli_query($link,$query_cria_manutencao);
	header("location: /admin/addons/torres/manutencaotorre.php");
}

if(isset($_POST['edita_manutencao'])){
    $idmanutencao = $_POST['idmanutencao'];
    $informacao = $_POST['informacao'];
    $data_manutencao = $_POST['data_manutencao'];
    $data_prox_manutencao = $_POST['data_prox_manutencao'];
    $cituacao = $_POST['cituacao'];

    $query_edita_manutencao = "UPDATE volt_manutencao SET removido=NULL";

    if($informacao != ""){
        $query_edita_manutencao .= ", informacao='$informacao'";
    }
    if($data_manutencao != ""){
        $query_edita_manutencao .= ", data_manutencao='$data_manutencao'";
    }
    if($data_prox_manutencao != ""){
        $query_edita_manutencao .= ", data_prox_manutencao='$data_prox_manutencao'";
    }
    if($cituacao != ""){
        $query_edita_manutencao .= ", cituacao='$cituacao'";
    }

    $query_edita_manutencao .= " WHERE id=$idmanutencao";
	$edita_manutenca  = mysqli_query($link,$query_edita_manutencao);
	header("location: /admin/addons/torres/manutencaotorre.php");
}

if(isset($_POST['deleta_manutencao'])){
    $idmanutencao = $_POST['idmanutencaodel'];
    $query_deletando_manutencao = "UPDATE volt_manutencao SET removido='$hoje' WHERE id='$idmanutencao'";
    $deletando_manutencao  = mysqli_query($link,$query_deletando_manutencao);
	header("location: /admin/addons/torres/manutencaotorre.php");
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>MK-AUTH :: <?php echo $Manifest->{'name'}; ?></title>

	<link href="../../estilos/mk-auth.css" rel="stylesheet" type="text/css" />
	<link href="../../estilos/font-awesome.css" rel="stylesheet" type="text/css" />
	<link href="../../estilos/bi-icons.css" rel="stylesheet" type="text/css" />
	<link href="style.css" rel="stylesheet" type="text/css" />

	<script src="../../scripts/jquery.js"></script>
	<script src="../../scripts/mk-auth.js"></script>

    <script>
        function confirmarDel() {
            // Exibe uma caixa de confirmação
            var confirmacao = window.confirm("Você tem certeza que deseja Deletar essa manutencao?");
            // Se o usuário clicar em "OK", o formulário será enviado
            if (confirmacao) {
                return true;
            } else {
                return false;  // Se o usuário clicar em "Cancelar", o formulário não será enviado
            }
        }
    </script>
</head>
<body>


	<div class="topo">
		<?php include('../../topo.php'); ?>
	</div>
<?php if(permicao($nivel_Acesso) == true || acesso() == 'manutencao'):?>

<div class="containermain">
    <nav class="breadcrumb has-bullet-separator is-centered" aria-label="breadcrumbs">
        <ul>
            <li><a href="/admin/addons/torres"> ADDON</a></li>
            <li class="is-active">
            <a href="#" aria-current="page"> <?php echo htmlspecialchars($Manifest->{'name'} . " - V " . $Manifest->{'version'}); ?> </a>
            </li>&nbsp;&nbsp;
            <div class="titulo">
            <?php echo $torre_nome;?>
            </div>
        </ul>
    </nav>&nbsp;&nbsp;

    <button onclick="abrirPopupcria()"  id="adminManutencao"><img src="img/mais.png" width="30px" height="30px"/></button>
    <button id="btn_form_busca"><img src="img/busca.png" width="30px" height="30px"/></button>
    <div class="overlay" id="overlay" onclick="fecharPopupcria()"></div>


    <div>
        <form  id="form_busca" method="get" style="display:none">
        <label for="torre">Torre:</label>
        <input type="text" id="torre" name="torre">
        <label for="cituacao">Cituação:</label>
        <select name="cituacao" id="cituacao" style="width:15%;">
            <option value=""></option>
            <option value="pendente">Pendente</option>
            <option value="concluido">Concluido</option>
            <option value="arquivado">Arquivado</option>
            <option value="Todos">Todos</option>
        </select>

        <input type="submit" class="salvar" value="buscar"/>
        </form>
    </div>



    <div>
        <table id="table1">
            <thead>
                <?php echo "";?>
                <th style="width:100px">Torre</th>
                <th style="width:300px">Informacao</th>
                <th style="width:100px">Data Manutencao</th>
                <th style="width:100px">Data Proxima Manutencao</th>
                <th style="width:60px">Cituacao</th>
                <th style="width:60px"></th>
            </thead>
            <tbody>
                <?php while($row_manutencao = mysqli_fetch_assoc($result_manutencao)):?>
                <tr>
                    <td><?php echo $row_manutencao['nome'];?></td>
                    <td><?php echo $row_manutencao['informacao'];?></td>
                    <td><?php echo date('d-m-Y', strtotime($row_manutencao['data_manutencao']));?></td>
                    <td><?php if($row_manutencao['data_prox_manutencao'] != ""){echo date('d-m-Y', strtotime($row_manutencao['data_prox_manutencao']));};?></td>
                    <td><?php echo $row_manutencao['cituacao'];?></td>
                    <td>
                    <button onclick="abrirPopupedita(<?php echo $row_manutencao['id'];?>)"  id="adminManutencao"><img src="img/atualizar.png" width="30px" height="30px"/></button>
                    
                    </td>
                </tr>
                <?php endwhile;?>
            </tbody>
        </table>
    </div>
</div>
<?php else : ?>
    <p class="no-data">Acesso não permitido!</p>
<?php endif; ?>
 	<?php include('../../baixo.php'); ?>
    <script src="../../menu.js.php"></script>
    <?php include('../../rodape.php'); ?>





<!--cria um amanutencao-->
<div class="popup" id="formPopupcriamanutencao">
    <h3 class="titulo">Cria uma Manutencao </h3><br><br>
    <form id="cria_manutencao" method="POST" >


        <label for="torre">Torre:</label>
        <select name="torre" id="torre" style="width:80%;">
            <?php while($row_torre = mysqli_fetch_assoc($result_torre)):?>
            <option value="<?php echo $row_torre['id'];?>"><?php echo $row_torre['nome'];?></option>
            <?php endwhile;?>
        </select><br><br>

        <label for="informacao">Info:</label>
        <textarea id="informacao" name="informacao" style="width:100%; "></textarea><br><br>

        <label for="Data Manutencao">Data Manutencao:</label>
        <input type="date" id="data_manutencao" name="data_manutencao" ><br><br>

        <label for="Data Prox Manutencao">Data Prox Manutencao:</label>
        <input type="date" id="data_prox_manutencao" name="data_prox_manutencao" ><br><br>

        <label for="cituacao">Cituacao:</label>
        <select name="cituacao" id="cituacao" style="width:80%;">
            <option value="pendente">Pendente</option>
            <option value="concluido">Concluido</option>
            <option value="arquivado">Arquivado</option>
        </select><br><br>

        <button type="submit" class="btn" name="cria_manutencao">Salvar</button>
        <button type="button" class="btn" onclick="fecharPopupcria()">Fechar</button>
    </form>
</div>

            <!--edita uma manutencao-->
<div class="popup" id="formPopupeditamanutencao">
    <h3 class="titulo">Editando A Manutencao </h3><br><br>
    <form id="edita_manutencao" method="POST" >

        <input type="hidden" name="idmanutencao" id="idmanutencao">

        <label for="informacao">Info:</label>
        <textarea id="informacao" name="informacao" style="width:100%; "></textarea><br><br>

        <label for="Data Manutencao">Data Manutencao:</label>
        <input type="date" id="data_manutencao" name="data_manutencao" ><br><br>

        <label for="Data Prox Manutencao">Data Prox Manutencao:</label>
        <input type="date" id="data_prox_manutencao" name="data_prox_manutencao" ><br><br>

        <label for="cituacao">Cituacao:</label>
        <select name="cituacao" id="cituacao" style="width:80%;">
            <option value="" selected></option>
            <option value="pendente">Pendente</option>
            <option value="concluido">Concluido</option>
            <option value="arquivado">Arquivado</option>
        </select><br><br>
    <div class="grid-container">
        <div>
            <button type="submit" class="btn" name="edita_manutencao">Salvar</button>
            </form>
            <button type="button" class="btn" onclick="fecharPopupedita()">Fechar</button>
        </div>
        <div>
            <form  method="post" onsubmit="return confirmarDel();">
                <input type="hidden" name="idmanutencaodel" id="idmanutencaodel">
                <button type="submit" class="btn" style="background-color:red" name="deleta_manutencao">Apagar</button>
            </form>
        </div>
    </div>
</div>



<script>

    // Função para Popup Cria
    function abrirPopupcria() {

        document.getElementById('formPopupcriamanutencao').style.display = 'block';
        document.getElementById('overlay').style.display = 'block';

        }

        function fecharPopupcria() {

        document.getElementById('formPopupcriamanutencao').style.display = 'none';
        document.getElementById('overlay').style.display = 'none';
    }

    function abrirPopupedita(id) {

        document.getElementById('formPopupeditamanutencao').style.display = 'block';
        document.getElementById('overlay').style.display = 'block';

        document.getElementById("idmanutencao").value = encodeURIComponent(id);
        document.getElementById("idmanutencaodel").value = encodeURIComponent(id);
        

}

   // Função para Popup edita
    function fecharPopupedita() {
        document.getElementById('formPopupeditamanutencao').style.display = 'none';
        document.getElementById('overlay').style.display = 'none';
    }


// Exibe a busca
var btnbusca = document.getElementById('btn_form_busca');
var formbusca = document.getElementById('form_busca');

btnbusca.addEventListener('click', function() {
  if(formbusca.style.display != 'block') {
    formbusca.style.display = 'block';
    return;
  }
  formbusca.style.display = 'none';
});

</script>


</body>
</html>
