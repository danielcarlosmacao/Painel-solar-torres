<?php

// Conexção com o Banco de Dados mk auth
$create_opcoes = mysqli_query(mysqli_connect("localhost", "root", "vertrigo", 'mkradius'), "CREATE database IF NOT EXISTS torre");


$link = mysqli_connect("localhost", "root", "vertrigo", 'torre');

//testa conexão
if (!$link) {
		die("Falha na conexão: " . mysqli_connect_error());
	}
//Verificar se a sesssão MKA_Usuario esta vazia
$usuario_logado = isset($_SESSION['MKA_Usuario']) ? $_SESSION['MKA_Usuario'] : $_SESSION['MM_Usuario'];

$permissao_padrao = "perm_relFat";


//Verifica se o usuario logado tenha permição
function permicao($permissao){


	global $link;
	global $usuario_logado;
	
	$query_permissao = mysqli_query($link, "SELECT usuario FROM sis_perm WHERE nome LIKE '$permissao' AND usuario LIKE '$usuario_logado' AND permissao LIKE 'sim'");

	if(acesso() == "admin" || acesso() == "superadmin" || acesso() == "usermanutencao" || acesso() == "user"){
		return  true;
	}else{
		if ($query_permissao) {
    $liberar_permissao = mysqli_num_rows($query_permissao);

    if ($liberar_permissao >= 1) {
        return true;
    } else {
        return false;
    }
}else {
    echo "Erro na Verificação da permição: " . mysqli_error($link);
    return  false;
}
}}

function acesso(){

	global $link;
	global $usuario_logado;


	$query_permissao_valida = mysqli_query($link, "SELECT nivel_acesso FROM volt_user WHERE nivel_acesso='superadmin' AND removido IS NULL");
	$nivel_acesso_valida = mysqli_num_rows($query_permissao_valida);

	if($nivel_acesso_valida >=1){
	$query_permissao = mysqli_query($link, "SELECT nivel_acesso FROM volt_user WHERE usuario='$usuario_logado' AND removido IS NULL");
	$nivel_acesso = mysqli_fetch_assoc($query_permissao);

	return $nivel_acesso['nivel_acesso'] ;

	}else{
		return 'superadmin';
	}

}	

function opcao($referencia){
	global $link;
	$query_opcoes_hgeracao = "SELECT * FROM volt_opcoes vo  WHERE referencia='$referencia' AND removido IS NULL LIMIT 1";
	$result_opcoeshgeracao = mysqli_query($link,$query_opcoes_hgeracao);
	$result_referencia = mysqli_fetch_assoc($result_opcoeshgeracao);
	return $result_referencia['valor'];

}

if(acesso() == "user" ){
echo "<style>
		#admin, .admin{
			display: none;
		}
		#adminManutencao, .adminManutencao{
			display: none;
		}
	</style>";
}
if(acesso() == "usermanutencao" ){
echo "<style>
		#admin, .admin{
			display: none;
		}
	</style>";
}
