<?php
// INCLUE FUNCOES DE ADDONS -----------------------------------------------------------------------
include('addons.class.php');

// INCLUE configuraçoes do addon -----------------------------------------------------------------------
include('config.php');

// VERIFICA SE O USUARIO ESTA LOGADO --------------------------------------------------------------
session_name('mka');
if (!isset($_SESSION)) session_start();
if (!isset($_SESSION['mka_logado']) && !isset($_SESSION['MKA_Logado'])) exit('Acesso negado... <a href="/admin/login.php">Fazer Login</a>');

//Permissao nessecaria para acessa o addon
$nivel_Acesso = $permissao_padrao;


$key = $_POST['key'];


if($key == "4600" && $_GET['rm'] == null){
    $criartabela = true;
}

//Criação das tabelas no primeiro acesso
if($criartabela == true){
    //function createTable(){
        $create_table_volt_torre = mysqli_query($link, "CREATE TABLE IF NOT EXISTS volt_torre (
        id INT(10) AUTO_INCREMENT PRIMARY KEY,
        nome VARCHAR(50) NOT NULL,
        voltagem INT DEFAULT 24,
        removido DATE NULL
        )");
    
        $create_table_volt_equipamento = mysqli_query($link, "CREATE TABLE IF NOT EXISTS volt_equipamento (
        id INT(10) AUTO_INCREMENT PRIMARY KEY,
        nome VARCHAR(50) NOT NULL,
        watts DECIMAL(7,2) NOT NULL,
        removido DATE NULL
        )");
    
        $create_table_volt_bateria = mysqli_query($link, "CREATE TABLE IF NOT EXISTS volt_bateria (
        id INT(10) AUTO_INCREMENT PRIMARY KEY,
        nome VARCHAR(50) NOT NULL,
        marca VARCHAR(50) NOT NULL,
        amperes INT NOT NULL,
        removido DATE NULL
        )");
    //amperes placa decimal----------------------------------------------------------------------------------
        $create_table_volt_placa = mysqli_query($link, "CREATE TABLE IF NOT EXISTS volt_placa (
        id INT(10) AUTO_INCREMENT PRIMARY KEY,
        nome VARCHAR(50) NOT NULL,
        watts INT NOT NULL,
        amperes DECIMAL(10,2) NOT NULL,
        removido DATE NULL
        )");
    
        $create_table_volt_consumo = mysqli_query($link, "CREATE TABLE IF NOT EXISTS volt_consumo (
        id INT(10) AUTO_INCREMENT PRIMARY KEY,
        identificacao varchar(20),
        id_torre INT NOT NULL,
        id_equipamento INT NOT NULL,
        ativo ENUM('s', 'n') DEFAULT 's',
        removido DATE NULL
        )");
    
        $create_table_volt_armazenamento = mysqli_query($link, "CREATE TABLE IF NOT EXISTS volt_armazenamento (
        id INT(10) AUTO_INCREMENT PRIMARY KEY,
        info VARCHAR(20),
        id_torre INT NOT NULL,
        id_bateria INT NOT NULL,
        quantidade int(2) NOT NULL,
        data_instalacao DATE,
        data_remocao DATE,
        ativo ENUM('s', 'n') DEFAULT 'n',
        percentualproducao DECIMAL(10,2) ,
        removido DATE NULL
        )");
    
        $create_table_volt_geracao = mysqli_query($link, "CREATE TABLE IF NOT EXISTS volt_geracao (
        id INT(10) AUTO_INCREMENT PRIMARY KEY,
        id_torre INT NOT NULL,
        id_placa INT NOT NULL,
        data_instalacao DATE,
        removido DATE NULL
        )");
    
        $create_opcoes = mysqli_query($link, "CREATE TABLE IF NOT EXISTS volt_opcoes (
        id INT(10) AUTO_INCREMENT PRIMARY KEY,
        referencia VARCHAR(50),
        valor VARCHAR(50),
        removido DATE NULL
        )");
    
        $create_manutencao = mysqli_query($link, "CREATE TABLE IF NOT EXISTS volt_manutencao (
        id INT(10) AUTO_INCREMENT PRIMARY KEY,
        id_torre INT NOT NULL,
        informacao VARCHAR(50),
        data_manutencao DATE,
        data_prox_manutencao DATE,
        cituacao ENUM('pendente', 'concluído', 'arquivado') DEFAULT 'pendente',
        removido DATE NULL
        )");
    
        $create_user = mysqli_query($link, "CREATE TABLE IF NOT EXISTS volt_user (
        id INT(10) AUTO_INCREMENT PRIMARY KEY,
        usuario VARCHAR(50),
        nivel_acesso VARCHAR(50),
        removido DATE NULL
        )");
    
        for($i=1;$i == 1; $i++){
        $alter_1_table_volt_consumo = mysqli_query($link, " ALTER TABLE volt_consumo ADD FOREIGN KEY(id_torre)  REFERENCES volt_torre(id)");
        $alter_2_table_volt_consumo = mysqli_query($link, " ALTER TABLE volt_consumo ADD FOREIGN KEY(id_equipamento)  REFERENCES volt_equipamento(id)");
    
        $alter_1_table_volt_armazenamento = mysqli_query($link, " ALTER TABLE volt_armazenamento ADD FOREIGN KEY(id_torre)  REFERENCES volt_torre(id)");
        $alter_2_table_volt_armazenamento = mysqli_query($link, " ALTER TABLE volt_armazenamento ADD FOREIGN KEY(id_bateria)  REFERENCES volt_bateria(id)");
    
        $alter_1_table_volt_geracao = mysqli_query($link, " ALTER TABLE volt_geracao ADD FOREIGN KEY(id_torre)  REFERENCES volt_torre(id)");
        $alter_2_table_volt_geracao = mysqli_query($link, " ALTER TABLE volt_geracao ADD FOREIGN KEY(id_placa)  REFERENCES volt_placa(id)");
    
        $alter_1_table_volt_limpeza = mysqli_query($link, " ALTER TABLE volt_manutencao ADD FOREIGN KEY(id_torre)  REFERENCES volt_torre(id)");
        }
    
    
        $dados_opcoe = mysqli_query($link,"INSERT INTO `volt_opcoes` VALUES (1,'horas_geracao','1',NULL),(2,'horas_autonomia','1',NULL),(3,'registro_pagina','10',NULL)");

        echo " <script type='text/javascript'> 
        alert('Serviço licenciado. Por favor Aguarde');
        window.location.replace('/admin/addons/torres/');
    </script>";
    }

    
    if($_GET['rm'] == "s" && $key == "4600"){
        $drop1 = mysqli_query($link,"DROP TABLE volt_armazenamento CASCADE");
        $drop2 = mysqli_query($link,"DROP TABLE volt_bateria CASCADE");
        $drop3 = mysqli_query($link,"DROP TABLE volt_consumo CASCADE");
        $drop4 = mysqli_query($link,"DROP TABLE volt_equipamento CASCADE");
        $drop5 = mysqli_query($link,"DROP TABLE volt_geracao CASCADE");
        $drop6 = mysqli_query($link,"DROP TABLE volt_manutencao CASCADE");
        $drop7 = mysqli_query($link,"DROP TABLE volt_opcoes CASCADE");
        $drop8 = mysqli_query($link,"DROP TABLE volt_placa CASCADE");
        $drop9 = mysqli_query($link,"DROP TABLE volt_torre CASCADE");
        $drop10 = mysqli_query($link,"DROP TABLE volt_user CASCADE");
        echo "alert('Serviço Excluido');  window.location.replace('/admin/addons/torres/');";
        
}

?>




<!DOCTYPE html>
    <html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Prompt para Enviar Dados</title>
        <script type="text/javascript">
            // Função que será chamada ao carregar a página
            window.onload = function() {
                var key = prompt("Por favor, insira Chave de ativação: CHAVE PADRAO 4600 ");
                
                if (key != null && key != "") {
                    // Se o usuário inserir um nome, preenche o formulário e envia
                    if(key == "4600"){
                        document.getElementById('key').value = key;
                        document.getElementById('formulario').submit();
                    }else{
                        alert("Chave Invalida");
                    }
                } else {
                    alert("Nenhuma chave foi inserido.");
                }
            }
        </script>
    </head>
    <body>
    
        <!-- Formulário oculto para enviar os dados para o PHP -->
        <form id="formulario" method="POST">
            <input type="hidden" id="key" name="key">
        </form>
    
    </body>
    </html>