<?php
// INCLUE FUNCOES DE ADDONS -----------------------------------------------------------------------
include('addons.class.php');

// INCLUE configuraçoes do addon -----------------------------------------------------------------------
include('config.php');

// VERIFICA SE O USUARIO ESTA LOGADO --------------------------------------------------------------
session_name('mka');
if (!isset($_SESSION)) session_start();
if (!isset($_SESSION['mka_logado']) && !isset($_SESSION['MKA_Logado'])) exit('Acesso negado... <a href="/admin/login.php">Fazer Login</a>');

//Permissao nessecaria para acessa o addon
$nivel_Acesso = $permissao_padrao;

//Buscas
$query_placa = "SELECT * FROM volt_placa WHERE removido IS NULL";
 $result_placa = mysqli_query($link,$query_placa);

 //cria torre

	$placapnome = $_POST['nome'];
	$placawatts = $_POST['watts'];
	$placaamperes = $_POST['amperes'];
	$iddelete = $_POST['placa_delete'];
	$idatualizar = $_GET['placa_atualiza'];


 if (isset($_POST['cria_placa'])) {

	$query_cria_placa = "INSERT INTO volt_placa(nome,watts,amperes) VALUES ('$placapnome','$placawatts','$placaamperes')";
	$cria_placa  = mysqli_query($link,$query_cria_placa);
	header("location: /admin/addons/torres/placas.php");

 }
 if (isset($_POST['placa_delete'])) {

	$hoje = date('Y-m-d');
	$query_cria_placa = "UPDATE volt_placa SET removido='$hoje' where id=$iddelete";
	$cria_placa  = mysqli_query($link,$query_cria_placa);
	header("location: /admin/addons/torres/placas.php");

 }
 if (isset($_POST['placa_up'])) {
	$placaupid = $_POST['placa_up'];
	$placapnome = $_POST['nome'];
	$placawatts = $_POST['watts'];
	$placaamperes = $_POST['amperes'];

	$query_up_placa = "UPDATE volt_placa SET nome='$placapnome', watts='$placawatts', amperes='$placaamperes'  where id=$placaupid";
	$up_placa  = mysqli_query($link,$query_up_placa);
	header("location: /admin/addons/torres/placas.php");

 }


?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>MK-AUTH :: <?php echo $Manifest->{'name'}; ?></title>

	<link href="../../estilos/mk-auth.css" rel="stylesheet" type="text/css" />
	<link href="../../estilos/font-awesome.css" rel="stylesheet" type="text/css" />
	<link href="../../estilos/bi-icons.css" rel="stylesheet" type="text/css" />
	<link href="style.css" rel="stylesheet" type="text/css" />

	<script src="../../scripts/jquery.js"></script>
	<script src="../../scripts/mk-auth.js"></script>
    <script>
        function confirmarDel() {
            // Exibe uma caixa de confirmação
            var confirmacao = window.confirm("Você tem certeza que deseja Deletar essa placa?");
            // Se o usuário clicar em "OK", o formulário será enviado
            if (confirmacao) {
                return true;
            } else {
                return false;  // Se o usuário clicar em "Cancelar", o formulário não será enviado
            }
        }
    </script>
</head>
<body>


	<div class="topo">
		<?php include('../../topo.php'); ?>
	</div>
<?php if(permicao($nivel_Acesso) == true):?>

	<div class="containermain">
		 <nav class="breadcrumb has-bullet-separator is-centered" aria-label="breadcrumbs">
            <ul>
                <li><a href="/admin/addons/torres"> ADDON</a></li>
                <li class="is-active">
                <a href="#" aria-current="page"> <?php echo htmlspecialchars($Manifest->{'name'} . " - V " . $Manifest->{'version'}); ?> </a>
                </li>

				<li>
				<button id="btn_form"  class="admin"><img src="img/mais.png" width="50px" height="50px"/></button>
				</li>
            </ul>
        </nav>
		<div>

		<div>
			<form id="my_form" action="/admin/addons/torres/placas.php" method="post">

				<label>Nome:</label>
				<input type="text" name="nome" VALUES="null"/>
				<label>Watts:</label>
				<input type="text" name="watts" VALUES="null"/>
				<label>Amperes:</label>
				<input type="number" name="amperes" step="0.01"/>
				<input type="submit" class="salvar" name="cria_placa"/>
			</form>
		</div>

		<table id="table1">
			<thead>
				<tr>
					<th>#</th>
					<th>Nome</th>
					<th>Watts</th>
					<th>Ah</th>
					<th style=" width: 200px;"></th>

				</tr>
			</thead>
			<tbody>
			<?php while ($row = mysqli_fetch_assoc( $result_placa )) : ?>
				<tr>
				<?php
					$id = $row['id'];

				?>
				<form method="post">
					<!-- -->
					<td><?php echo $id . $query_up_placa;?></td>
					<!-- -->
					<td><?php if($idatualizar == $id){echo "<input name='nome' value=".$row['nome'].">";}else{echo $row['nome'];};?></td>
					<!-- -->
					<td><?php if($idatualizar == $id){echo "<input name='watts' value=".$row['watts'].">";}else{echo $row['watts'];};?></td>
					<!-- -->
					<td><?php if($idatualizar == $id){echo "<input name='amperes' value=".$row['amperes'].">";}else{echo $row['amperes'];};?></td>

					<!-- -->
					<td >
					<div class="grid-container-button" >
					<button type="submit" name="placa_up" <?php if($idatualizar != $id){echo "style='display: none;'";}?> value="<?php echo $id;?>"><img src="img/ok.png" width="30px" height="30px"/></button>
					</form>
					<div class="grid-container-button">
					<form method="get">
						<button type="submit" name="placa_atualiza" <?php if($idatualizar == $id){echo "style='display: none;'";}?> value="<?php echo $id;?>"  id="admin"><img src="img/atualizar.png" width="30px" height="30px"/></button>
					</form>
					<form method="post" onsubmit="return confirmarDel();" >
						<button type="submit" name="placa_delete" <?php if($idatualizar == $id){echo "style='display: none;'";}?> value="<?php echo $id;?>"  id="admin"><img src="img/lixeira.png" width="30px" height="30px"/></button>
					</form>
						<a href="/admin/addons/torres/placas.php">
							<button <?php if($idatualizar != $id){echo "style='display: none;'";}?> value="<?php echo $id;?>"><img src="img/x.png" width="30px" height="30px"/></button>
						</a>
					</div>
					</div>
					</td>
				</tr>
			<?php endwhile;?>
			</tbody>

		</table>


	</div>
<?php else : ?>
    <p class="no-data">Acesso não permitido!</p>
<?php endif; ?>
 	<?php include('../../baixo.php'); ?>
    <script src="../../menu.js.php"></script>
    <?php include('../../rodape.php'); ?>

<script>
var btn = document.getElementById('btn_form');
var form = document.getElementById('my_form');

btn.addEventListener('click', function() {
  if(form.style.display != 'block') {
    form.style.display = 'block';
    return;
  }
  form.style.display = 'none';
});
</script>
</body>
</html>
