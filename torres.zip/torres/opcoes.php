<?php
// INCLUE FUNCOES DE ADDONS -----------------------------------------------------------------------
include('addons.class.php');

// INCLUE configuraçoes do addon -----------------------------------------------------------------------
include('config.php');

// VERIFICA SE O USUARIO ESTA LOGADO --------------------------------------------------------------
session_name('mka');
if (!isset($_SESSION)) session_start();
if (!isset($_SESSION['mka_logado']) && !isset($_SESSION['MKA_Logado'])) exit('Acesso negado... <a href="/admin/login.php">Fazer Login</a>');

//Permissao nessecaria para acessa o addon
$nivel_Acesso = $permissao_padrao;


//Buscas

$sis_user = mysqli_query(mysqli_connect("localhost", "root", "vertrigo", 'mkradius'), "SELECT * FROM sis_acesso WHERE ativo='sim' ORDER BY login ASC");

$query_user = "SELECT * FROM volt_user WHERE removido IS NULL ORDER BY 'usuario' ASC";
$result_user = mysqli_query($link,$query_user);



if(isset($_POST['up_opcoes'])){
    $horas_geracao = $_POST['horas_geracao'];
    $horas_autonomia = $_POST['horas_autonomia'];
    $registro_pagina = $_POST['registro_pagina'];
    $query_op_geracao = "UPDATE volt_opcoes SET valor = '$horas_geracao' WHERE referencia = 'horas_geracao'";
    $query_op_autonomia = "UPDATE volt_opcoes SET valor = '$horas_autonomia' WHERE referencia = 'horas_autonomia'";
    $query_op_autonomia = "UPDATE volt_opcoes SET valor = '$registro_pagina' WHERE referencia = 'registro_pagina'";

    $cria_op_geracao  = mysqli_query($link,$query_op_geracao);
    $cria_op_autonomia  = mysqli_query($link,$query_op_autonomia);
    header("location: /admin/addons/torres/opcoes.php");

}


if(isset($_POST['up_user'])){
    $usuario = $_POST['usuario'];
    $nivel_acesso = $_POST['nivel_acesso'];

    $query_verifica = "SELECT * FROM volt_user WHERE usuario='$usuario' AND removido IS NULL";
    $verifica  = mysqli_query($link,$query_verifica);

    if($verifica->num_rows ==  0){
    $query_cria_user = "INSERT INTO volt_user(usuario,nivel_acesso) VALUES ('$usuario','$nivel_acesso')";
    $cria_user  = mysqli_query($link,$query_cria_user);
    
    header("location: /admin/addons/torres/opcoes.php");

    }else{
        echo "<script> alert('Usuario ja exite')</script>";
    }

}

if(isset($_POST['user_delete'])){
    $id_user = $_POST['user_delete'];
	$hoje = date('Y-m-d');

    $query_user_delete = "UPDATE volt_user SET removido = '$hoje' WHERE id = '$id_user'";
    $remove_user = mysqli_query($link,$query_user_delete);
    header("location: /admin/addons/torres/opcoes.php");

}

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>MK-AUTH :: <?php echo $Manifest->{'name'}; ?></title>

	<link href="../../estilos/mk-auth.css" rel="stylesheet" type="text/css" />
	<link href="../../estilos/font-awesome.css" rel="stylesheet" type="text/css" />
	<link href="../../estilos/bi-icons.css" rel="stylesheet" type="text/css" />
	<link href="style.css" rel="stylesheet" type="text/css" />

	<script src="../../scripts/jquery.js"></script>
	<script src="../../scripts/mk-auth.js"></script>

</head>
<body>


	<div class="topo">
		<?php include('../../topo.php'); ?>
	</div>
<?php if(acesso() == 'superadmin'):?>

<div class="containermain">

    <nav class="breadcrumb has-bullet-separator is-centered" aria-label="breadcrumbs">
        <ul>
            <li><a href="/admin/addons/torres"> ADDON</a></li>
            <li class="is-active">
            <a href="#" aria-current="page"> <?php echo htmlspecialchars($Manifest->{'name'} . " - V " . $Manifest->{'version'}); ?> </a>
            </li>&nbsp;&nbsp;
            <div class="titulo">
            <?php echo $torre_nome;?>
            </div>
        </ul>
    </nav>&nbsp;&nbsp;

    <div class="maincenter">
        <div class="center">
            <form  method="post">
                <label>Horas de geracao:</label>
                <input type="number" style="width: 10%;" name="horas_geracao" value="<?php echo opcao(horas_geracao);?>"/>
                <label>Horas de autonomia:</label>
                <input type="number" style="width: 10%;"  name="horas_autonomia" value="<?php echo opcao(horas_autonomia);?>"/></br>&nbsp;&nbsp;
                <label>Registro por pagina:</label>
                <input type="number" style="width: 10%;"  name="registro_pagina" value="<?php echo opcao(registro_pagina);?>"/>&nbsp;&nbsp;
                <button type="submit" name="up_opcoes" class="salvar" >Atualizar</button>
            </form>
        </div></br></br></br>
        <div style="margin-top: 10px; display: flex; margin-left: 25%;">
            <!-- Formulário para upload de arquivo -->
            <form action="database.php" method="POST" enctype="multipart/form-data">
                <input type="file" name="backup_file" id="backup_file" accept=".sql" required>
                <button  class="import" type="submit" name="import">Importar Backup</button>
            </form>

            <!-- O botão que acionará o download do backup -->
            <form method="POST" action="database.php">
                <button class="export" type="submit" name="export">Exportar Backup</button>
            </form>
        </div>

        <div class="center" style="margin-top:100px">
            <table id="table1">
                <thead>
                    <tr>
                        <th>Usuario</th>
                        <th>Nivel acesso</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($row_user = mysqli_fetch_assoc($result_user)):?>
                    <tr>
                        <td><?php echo $row_user['usuario'];?></td>
                        <td><?php echo $row_user['nivel_acesso'];?></td>
                        <td>
                            <form method="post">
                                <button name="user_delete" type="submit" value="<?php echo $row_user['id'];?>"><img src="img/lixeira.png" width="30px" height="30px"/></button>
                            </form>
                        </td>
                    </tr>
                    <?php endwhile;?>
                    <tr>
                        <form method="post">
                            <td><select name="usuario">
                           <?php while($row_sis_user = mysqli_fetch_assoc($sis_user)):?>
                                <option value="<?php echo $row_sis_user['login'];?>"><?php echo $row_sis_user['login'];?></option>
                                <?php endwhile?>
                            </select></td>
                            <td>
                                <select name="nivel_acesso" id="nivel_acesso">
                                <option value="superadmin">Super Admin</option>
                                    <option value="admin">Admin</option>
                                    <option value="manutencao">Manutencao</option>
                                    <option value="usermanutencao">UserManutencao</option>
                                    <option value="user">User</option>
                                    
                                </select>
                            </td>
                            <td><Button type="submit"  name="up_user"><img src="img/ok.png" width="30px" height="30px"/></Button></td>
                    </form>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php else : ?>
    <p class="no-data">Acesso não permitido!</p>
<?php endif; ?>
 	<?php include('../../baixo.php'); ?>
    <script src="../../menu.js.php"></script>
    <?php include('../../rodape.php'); ?>


</body>
</html>
