<?php
// INCLUE FUNCOES DE ADDONS -----------------------------------------------------------------------
include('addons.class.php');

// INCLUE configuraçoes do addon -----------------------------------------------------------------------
include('config.php');

// VERIFICA SE O USUARIO ESTA LOGADO --------------------------------------------------------------
session_name('mka');
if (!isset($_SESSION)) session_start();
if (!isset($_SESSION['mka_logado']) && !isset($_SESSION['MKA_Logado'])) exit('Acesso negado... <a href="/admin/login.php">Fazer Login</a>');

//Permissao nessecaria para acessa o addon
$nivel_Acesso = $permissao_padrao;


//Buscas
$idtorre = $_GET['idtorre'];



//$referencia = 'horas_geracao';


$hoje = date('Y-m-d');



$query_torre = "SELECT * FROM volt_torre vt WHERE id = $idtorre limit 1";
$result_torre = mysqli_query($link,$query_torre);
$row_torre = mysqli_fetch_assoc($result_torre);
$torre_nome = $row_torre['nome'];
$torre_voltagem = $row_torre['voltagem'];

$query_bateria_info = "SELECT * FROM volt_bateria vb  WHERE removido IS NULL ORDER BY nome ASC  ";
$result_bateria_info = mysqli_query($link,$query_bateria_info);

$query_bateria = "SELECT va.id,va.info,va.id_torre,va.id_bateria,va.quantidade,va.data_instalacao,va.data_remocao,va.ativo,va.percentualproducao, va.removido,vb.nome,vb.marca,vb.amperes,vb.removido  FROM volt_armazenamento va join volt_bateria vb  WHERE id_torre = $idtorre AND va.id_bateria  = vb.id AND va.removido IS NULL ORDER BY data_instalacao ASC ";
$result_bateria = mysqli_query($link,$query_bateria);

$query_consumo = "SELECT vc.id, vc.identificacao, vc.id_torre, vc.ativo,  ve.nome, ve.watts FROM volt_consumo vc join volt_equipamento ve  WHERE id_torre = $idtorre AND vc.id_equipamento = ve.id AND vc.removido IS NULL ORDER BY nome ASC";
$result_consumo = mysqli_query($link,$query_consumo);

$query_consumo2 = "SELECT vc.id, vc.identificacao, vc.id_torre, vc.ativo,  ve.nome, ve.watts FROM volt_consumo vc join volt_equipamento ve  WHERE id_torre = $idtorre AND vc.id_equipamento = ve.id AND ativo='s' AND vc.removido IS NULL";
$result_consumo2 = mysqli_query($link,$query_consumo2);


$query_equip = "SELECT * FROM volt_equipamento WHERE removido IS NULL ORDER BY nome ASC";
$result_equip = mysqli_query($link,$query_equip);

$query_placa_info = "SELECT * FROM volt_placa vp WHERE removido IS NULL ORDER BY nome ASC";
$result_placa_info = mysqli_query($link,$query_placa_info);

$query_geracao = "SELECT  vg.id, vg.id_torre, vg.id_placa, vg.data_instalacao, vp.nome, vp.amperes, vp.watts  FROM volt_geracao vg join volt_placa vp  WHERE id_torre = $idtorre AND vg.id_placa = vp.id AND vg.removido IS NULL";
$result_geracao = mysqli_query($link,$query_geracao);



if ($_SERVER["REQUEST_METHOD"] == "POST") {

// tabela Armazenamento
if (isset($_POST['add_bat_torre'])) {

	$info = $_POST['info'];
	$id_torre = $_POST['add_bat_torre'];
	$id_bateria = $_POST['bateria'];
	$quantidade = $_POST['quantidade'];
	$data_instalacao = $_POST['data_instalacao'];
	
	/*if($data_instalacao == ""){
		$data_instalacao = "NULL";
	}*/

if($quantidade != ""){
	if($data_instalacao == ""){
		$query_cria_bat_torre = "INSERT INTO volt_armazenamento(info,id_torre,id_bateria,quantidade) VALUES ('$info','$id_torre','$id_bateria','$quantidade')";
	}else{
		$query_cria_bat_torre = "INSERT INTO volt_armazenamento(info,id_torre,id_bateria,quantidade,data_instalacao) VALUES ('$info','$id_torre','$id_bateria','$quantidade','$data_instalacao')";
	}
	$cria_bat_torre  = mysqli_query($link,$query_cria_bat_torre);
	header("location: /admin/addons/torres/torre.php?idtorre=$id_torre");
}
};
if(isset($_POST['bateria_delete'])){

	$id_bateria_del = $_POST['bateria_delete'];
	$query_bateria_del ="UPDATE volt_armazenamento SET removido='$hoje' where id=$id_bateria_del";
	$bateria_del  = mysqli_query($link,$query_bateria_del);
	header("location: /admin/addons/torres/torre.php?idtorre=$idtorre");
}
if(isset($_POST['bateria_atualizar'])){

	$query_bateria_atu = "SELECT va.id,va.info,va.id_torre,va.id_bateria,va.quantidade,va.data_instalacao,va.data_remocao,va.ativo,va.removido,vb.nome,vb.marca,vb.amperes,vb.removido  FROM volt_armazenamento va join volt_bateria vb  WHERE id_torre = $idtorre AND va.id_bateria  = vb.id AND va.removido IS NULL AND va.ativo='s' ";
	$result_bateria_atu = mysqli_query($link,$query_bateria_atu);

	$idbateria_up = $_POST['idbateria'];
	$persentualBat_up = $_POST['persentualBat'];
	$informacao_up = $_POST['informacao'];
	$data_instalacao_up = $_POST['data_instalacao'];
	$data_remocao_up = $_POST['data_remocao'];

	$query_up_bateria = "UPDATE volt_armazenamento SET removido=NULL";
	if($informacao_up != ""){
		$query_up_bateria .=" , info='$informacao_up'";
	}if($data_instalacao_up != ""){
		$query_up_bateria .= " , data_instalacao='$data_instalacao_up'";
	}if($data_remocao_up != ""){
		if($data_remocao_up == date('Y-m-d', strtotime('+1 day', strtotime($hoje)))){
			$query_up_bateria .= " , data_remocao=null, percentualproducao=null";
		}else{
		$query_up_bateria .= " , data_remocao='$data_remocao_up', ativo='n', percentualproducao='$persentualBat_up' ";
		}
	}if($data_remocao_up == ""){
		if(isset($_POST['ativo'])){
			if($result_bateria_atu->num_rows <=0){
				$query_up_bateria .= " , ativo='s'";
			}
		}if(isset($_POST['teste'])){
			$query_up_bateria .= " , ativo='n'";
		}
}



	$query_up_bateria .= " WHERE id=$idbateria_up";

	$up_bateria = mysqli_query($link,$query_up_bateria);
	header("location: /admin/addons/torres/torre.php?idtorre=$idtorre");

}
//tabela consumo
if(isset($_POST['add_equip'])){
	$id_torre = $_POST['add_equip'];
	$info_equip= $_POST['info'];
	$id_equip = $_POST['equip'];

	$query_cria_equip_torre = "INSERT INTO volt_consumo(identificacao,id_torre,id_equipamento) VALUE ('$info_equip','$id_torre','$id_equip') ";
	$cria_equip_torre   = mysqli_query($link,$query_cria_equip_torre);
	header("location: /admin/addons/torres/torre.php?idtorre=$id_torre");
}
if(isset($_POST['equip_delete'])){

	$id_equip_delete = $_POST['equip_delete'];
	$query_equip_delete ="UPDATE volt_consumo SET removido='$hoje' where id=$id_equip_delete";
	$equip_delete  = mysqli_query($link,$query_equip_delete);
	header("location: /admin/addons/torres/torre.php?idtorre=$idtorre");
}
if(isset($_POST['equip_update'])){

	$id_equip_up = $_POST['equip_update'];
	$status_equipamento = $_POST['ativo'];
	if($status_equipamento == "s"){
		$query_equip_up = "UPDATE volt_consumo SET ativo='n' where id=$id_equip_up";
	}else{
		$query_equip_up = "UPDATE volt_consumo SET ativo='s' where id=$id_equip_up";
	}
	$equip_up  = mysqli_query($link,$query_equip_up);
	header("location: /admin/addons/torres/torre.php?idtorre=$idtorre");
}

//tabela geracao
if(isset($_POST['add_placa'])){
	$id_torre = $_POST['add_placa'];
	$id_placa= $_POST['placa'];
	$data_instalacao = $_POST['data_instalacao'];
	if($data_instalacao == ""){
		$data_instalacao = date('Y-m-d');
	}

	$query_cria_placa_torre = "INSERT INTO volt_geracao(id_torre,id_placa, data_instalacao) VALUE ('$id_torre','$id_placa', '$data_instalacao') ";
	$cria_placa_torre   = mysqli_query($link,$query_cria_placa_torre);
	header("location: /admin/addons/torres/torre.php?idtorre=$id_torre");

}

if(isset($_POST['placa_delete'])){

	$id_placa_delete = $_POST['placa_delete'];
	$query_placa_delete ="UPDATE volt_geracao SET removido='$hoje' where id=$id_placa_delete";
	$equip_placa  = mysqli_query($link,$query_placa_delete);
	header("location: /admin/addons/torres/torre.php?idtorre=$idtorre");
}

if(isset($_POST['edita_torre'])){
	$idtorre = $_POST['torre'];
	$nome = $_POST['nome'];
	$voltagem = $_POST['voltagem'];
	$query_edita_torre = "UPDATE volt_torre SET nome='$nome', voltagem='$voltagem' WHERE id='$idtorre'";
	$edita_torre = mysqli_query($link,$query_edita_torre);
	header("location: /admin/addons/torres/torre.php?idtorre=$idtorre");

}

}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>MK-AUTH :: <?php echo $Manifest->{'name'}; ?></title>

	<link href="../../estilos/mk-auth.css" rel="stylesheet" type="text/css" />
	<link href="../../estilos/font-awesome.css" rel="stylesheet" type="text/css" />
	<link href="../../estilos/bi-icons.css" rel="stylesheet" type="text/css" />
	<link href="style.css" rel="stylesheet" type="text/css" />

	<script src="../../scripts/jquery.js"></script>
	<script src="../../scripts/mk-auth.js"></script>

</head>
<body>
	<div class="topo">
		<?php include('../../topo.php'); ?>
	</div>
<?php if(permicao($nivel_Acesso) == true):?>

	<div class="containermaintorre">
		 <nav class="breadcrumb has-bullet-separator is-centered" aria-label="breadcrumbs">
            <ul>
                <li><a href="/admin/addons/torres"> ADDON</a></li>
                <li class="is-active">
                <a href="#" aria-current="page"> <?php echo htmlspecialchars($Manifest->{'name'} . " - V " . $Manifest->{'version'}); ?> </a>
                </li>&nbsp;&nbsp;
            </ul>
			<div class="titulo">
				<button id="btn_form" class="buttonLink"><?php echo $torre_nome ;?></button>
				</div>
        </nav>
		

	</div>		<div>
		<form id="my_form_edit" method="post" style="display:none;">
				<label>Nome:</label>
				<input type="text" name="nome" VALUE="<?php echo $torre_nome;?>" required/>
				<label>Voltagem:</label>
				<input type="number" id="voltagem" name="voltagem" VALUE="<?php echo $torre_voltagem;?>" required/>
				<input type="number" id="torre" name="torre" hidden VALUE="<?php echo $idtorre;?>" />
				<button type="submit" class="salvar" name="edita_torre" >Salvar</button>
			</form>
		</div>
	<?php
		$consumoAhhora = 0;
		while($row_consumo2 = mysqli_fetch_assoc($result_consumo2)){
			$consumoWattshora = $consumoWattshora + $row_consumo2['watts'];
		}
		$result_consumo->data_seek(0);

		$consumoAhhora = $consumoWattshora / $torre_voltagem;
		$consumoAhDia = $consumoAhhora * 24;
		$BateriaNessecaria = $consumoAhhora * opcao(horas_autonomia);
		$AhPorDia = $consumoAhDia / opcao(horas_geracao);
		$wattsPainel = $AhPorDia * $torre_voltagem;

	?>
<div class="grid-container">
	<div class="grid-item">
	<div class="titulo">Bateria</div>
		<table id="table1" class="armazenamento" >
			<thead>
				<tr>
					<th style=" width: 200px;">Informacao</th>
					<th style=" width: 45px;">Nº</th>
					<th style=" width: 100px;">Bateria</th>
					<th style=" width: 50px;">Ah</th>
					<th style=" width: 120px;">Data Inst.</th>
					<th style=" width: 120px;">Data Rem.</th>
					<th style=" width: 75px;">Ah total</th>
					<th style=" width: 80px;">%</th>
					<th style=" width: 70px;">Anos</th>
					<th>.</th>
				</tr>
			</thead>
			<tbody>
				<?php while($row_bateria = mysqli_fetch_assoc($result_bateria)):?>
				<tr <?php if($row_bateria['ativo'] == "s"){echo "style='font-weight: bold'";}?>>
					<?php $idbateria = $row_bateria['id'];?>
					<!-- -->
					<td><?php echo $row_bateria['info'] ; //echo $query_up_bateria ?></td>
					<!-- -->
					<td><?php echo $row_bateria['quantidade'];?></td>
					<!-- -->
					<td><?php echo $row_bateria['marca'];?></td>
					<!-- -->
					<td><?php echo $row_bateria['amperes'];?></td>
					<!-- -->
					<td><?php if($row_bateria['data_instalacao']!= ""){echo date('d-m-Y', strtotime($row_bateria['data_instalacao']));};?></td>
					<!-- -->
					<td><?php if($row_bateria['data_remocao'] != ""){echo date('d-m-Y', strtotime($row_bateria['data_remocao']));};?></td>
					<!-- -->
					<td><?php
						$somaahbat = $row_bateria[quantidade] * $row_bateria['amperes'];
						$tipo_div_bat = $torre_voltagem / 12;
						$totalAhBat =  $somaahbat/$tipo_div_bat;
						echo round($totalAhBat, 1);
						
					?></td>
					<!-- -->
					<td><?php
						$persentualBat = round((($BateriaNessecaria / $totalAhBat)*100),2);
						if($row_bateria['data_remocao'] == ""){
							echo $persentualBat . " % ";
						}else{
							if($row_bateria['percentualproducao'] != ""){
								echo $row_bateria['percentualproducao'];
							}else{
								echo "<text style='color:#A4A4A4'>".$persentualBat . " % "."</text>";
							}
						}
					?></td>
					<!-- -->
					<td><?php
						$data_instalacao = strtotime($row_bateria['data_instalacao']);
						$hojedecimal = strtotime($hoje);
						
						if($row_bateria['data_remocao']==true){
							$data_remocao = strtotime($row_bateria['data_remocao']);
				
							$diferenca = ($data_remocao-$data_instalacao)/ (60 * 60 * 24);

							echo(number_format($diferenca/365,2));


						}else{
							echo(number_format((($hojedecimal-$data_instalacao)/ (60 * 60 * 24))/365,2));
						}
					?></td>
					<td>
						<div class="grid-container-button">
							<div class="grid-item-button">
								<form method="post">
									<button name="bateria_delete" type="submit" value="<?php echo $idbateria;?>"><img src="img/lixeira.png" width="30px" height="30px"/></button>
								</form>
							</div>
							<div class="grid-item-button">
								<!--<form method="post">
									<input type="hidden" id="idbateria" name="idbateria" value="<?php echo $idbateria;?>">
									<input type="hidden" id="informacao" name="informacao" value="<?php echo $row_bateria['info'];?>">
									<input type="hidden" id="data_instalacao" name="data_instalacao" value="<?php echo  $row_bateria['data_instalacao'];?>">
									<input type="hidden" id="data_remocao" name="data_remocao" value="<?php echo $row_bateria['data_remocao'];?>">
									<button  onclick="getBateriaInput()" name="bateria_atualizar"  ><img src="img/atualizar.png" width="30px" height="30px"/></button>
								</form>-->
								<button onclick="abrirPopup(<?php echo $idbateria;?>)"><img src="img/atualizar.png" width="30px" height="30px"/></button>
								<div class="overlay" id="overlay" onclick="fecharPopup()"></div>
							</div>
							
							<div class="popup" id="formPopupAtualizaBat">
								<h3 class="titulo">Atualizar Bateria </h3><br><br>
								<form id="bateria_atualizar" method="POST" >
									<input type="hidden" id="idbateria" name="idbateria" >
									<input type="hidden" id="persentualBat" name="persentualBat" value="<?php echo $persentualBat;?>" >
									
									<label for="informacao">Producao:</label>
									<input type="checkbox" id="ativo" name="ativo" >
									
									<label for="informacao">Teste:</label>
									<input type="checkbox" id="teste" name="teste" ><br><br>

									<label for="informacao">Info:</label>
									<input type="text" id="informacao" name="informacao" style="width:100%;"><br><br>

									<label for="Data instalacao">Data Instalacao:</label>
									<input type="date" id="data_instalacao" name="data_instalacao" ><br><br>

									<label for="Data instalacao">Data Remocao:</label>
									<input type="date" id="data_remocao" name="data_remocao" ><br><br>

									<button type="submit" class="btn" name="bateria_atualizar">Salvar</button>
									<button type="button" class="btn" onclick="fecharPopup()">Fechar</button>
								</form>
							</div>
						</div>
					</td>
				</tr>
				<?php endwhile?>
				<tr>
			<form method="POST">
					<!-- -->
					<td><input type="text" style="width: 100%;" name="info"/></td>
					<!-- -->
					<td><input type="number" name="quantidade" min="1" max="24" style=" width:100%;"/></td>
					<!-- -->
					<td> <select id="bateria" style="width:160% " name="bateria">
					<?php while($row_bateria_info = mysqli_fetch_assoc($result_bateria_info)):?>
					<option value="<?php echo $row_bateria_info['id'];?>"><?php echo $row_bateria_info['nome'];?></option>
					<?php endwhile;?>

					</select></td>
					<td></td>
					<td><input type="date" style=" width:100%;" name="data_instalacao"/></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td><button type="submit" name="add_bat_torre" value="<?php echo $idtorre;?>"><img src="img/ok.png" width="30px" height="30px"/></button>
					</form></td>
				</tr>
			</tbody>
		</table>
  	</div>
	<div class="grid-item">
	<div class="titulo">Resumo</div>
		<table id="table1">
			<thead>
				<tr>
					<th>#</th>
					<th>#</th>
					<th>#</th>
					<th>#</th>

				</tr>
			</thead>
			<tbody>
				<tr>
					<!-- -->
					<td>Horas Geracao</td>
					<!-- -->
					<td><?php echo opcao(horas_geracao);?></td>
					<!-- -->
					<td>Horas autonomia</td>
					<!-- -->
					<td><?php echo opcao(horas_autonomia);?></td>
				</tr>
				<tr>
					<!-- -->
					<td>Consumo Ah/Hora</td>
					<!-- -->
					<td><?php echo round($consumoAhhora, 2);?></td>
					<!-- -->
					<td>Bateria necessaria</td>
					<!-- -->
					<td><?php echo round($BateriaNessecaria, 2);?></td>
				</tr>
				<tr>
					<!-- -->
					<td>Consumo Ah/Dia</td>
					<!-- -->
					<td><?php echo round($consumoAhDia, 2);?></td>
					<!-- -->
					<td>Ah necessario gerar por <?php echo opcao(horas_geracao);?>h/dia</td>
					<!-- -->
					<td><?php echo round($AhPorDia, 2);?></td>
				</tr>
				<tr>
					<!-- -->
					<td>watts do painel</td>
					<!-- -->
					<td><?php echo $wattsPainel;?></td>
					<!-- -->
					<td>Voltagem</td>
					<!-- -->
					<td><?php echo $torre_voltagem;?></td>
				</tr>
			</tbody>
		</table>
  	</div>
</div>
</br>
<div class="grid-container">
	<div class="grid-item">
	<div class="titulo"><?php echo mysqli_num_rows($result_consumo);?> Equipamentos </div>
		<table id="table1">
			<thead>
				<tr>
					<th>Info</th>
					<th>Equipamento</th>
					<th>Watts</th>
					<th></th>
				</tr>
			</thead>
			<tbody>
			<?php while($row_consumo = mysqli_fetch_assoc($result_consumo)):?>
				<tr style="<?php if($row_consumo['ativo'] == 'n'){ echo 'color:#848484';}else{echo 'font-weight: bold';}?>">
					<!-- -->
					<td><?php echo $row_consumo['identificacao'];?></td>
					<!-- -->
					<td><?php echo $row_consumo['nome']?></td>
					<!-- -->
					<td><?php echo $row_consumo['watts'];?></td>
					<td>
					<div class="grid-container-button">
						<div class="grid-item-button">
							<form method="post">
								<button name="equip_delete" type="submit" value="<?php echo $row_consumo['id'];?>"><img src="img/lixeira.png" width="30px" height="30px"/></button>
							</form>
						</div>
						<div class="grid-item-button">
							<form method="post">
								<input type="hidden" name="ativo" value="<?php echo $row_consumo['ativo'];?>">
								<button name="equip_update" type="submit" value="<?php echo $row_consumo['id'];?>"><img src="img/atualizar.png" width="30px" height="30px"/></button>
							</form>
						</div">
					</div>
					</td>
				</tr>
				<?php endwhile;?>
				<form method="post">
					<tr>
					<!-- -->
					<td><input type="text" style="width:100%" name="info"/></td>
					<!-- -->
					<td><select id="equip" name="equip" style="width: 100%;">
					<?php while($row_equip_info = mysqli_fetch_assoc($result_equip)):?>
					<option value="<?php echo $row_equip_info['id'];?>"><?php echo $row_equip_info['nome'];?></option>
					<?php endwhile;?>

					</select></td>
					<!-- -->
					<td></td>
					<td><button type="submit" name="add_equip" value="<?php echo $idtorre;?>"><img src="img/ok.png" width="30px" height="30px"/></button></td>
				</tr>
				</form>
			</tbody>
		</table>
	</div>
  <div class="grid-item">
  <div class="titulo">Placa solar</div>
		<table id="table1">
			<thead>
				<tr>
					<th>Info</th>
					<th>Data instalação</th>
					<th>Ah</th>
					<th>Watts</th>
					<th></th>
				</tr>
			</thead>
			<tbody>
			<?php $totalAhPlaca = 0; $totalWattsPlaca = 0;
				while($row_geracao = mysqli_fetch_assoc($result_geracao)):?>
				<tr>
					<!-- -->
					<td><?php echo $row_geracao['nome'];?></td>
					<!-- -->
					<td style=" width: 150px;"><?php echo date('d-m-Y', strtotime($row_geracao['data_instalacao']));?></td>
					<!-- -->
					<td style=" width: 100px;"><?php echo $row_geracao['amperes']; $totalAhPlaca = $totalAhPlaca +  $row_geracao['amperes'];?></td>
					<!-- -->
					<td style=" width: 100px;"><?php echo $row_geracao['watts']; $totalWattsPlaca = $totalWattsPlaca + $row_geracao['watts'];?></td>
					<!-- -->
					<td style=" width: 100px;">
					<form method="post">
							<button name="placa_delete" type="submit" value="<?php echo $row_geracao['id'];?>"><img src="img/lixeira.png" width="30px" height="30px"/></button>
						</form>
					</td>
				</tr>
				<?php endwhile?>
				<!-- Total Placas-->
				<tr style=" font-weight: bold;">
					<td>Total Placas</td>
					<?php 
						$percentualAhP = round((($AhPorDia/$totalAhPlaca)*100), 2);
						$percentualWP = round((($wattsPainel/$totalWattsPlaca)*100), 2);

						
					if(is_nan($percentualAhP)){
						$percentualAhP = "";
					}
					if(is_nan($percentualWP)){
						$percentualWP = "";
					}
					?>
					<td style="text-align: center;" colspan="2"><?php echo $totalAhPlaca . " Ah&nbsp;&nbsp;" . $percentualAhP . "%"; ?></td>
					<td style="text-align: center;" colspan="2"><?php echo $totalWattsPlaca. "W&nbsp;&nbsp;" . $percentualWP . "%";?></td>
				</tr>
				<form method="post">
					<tr>
					<!-- -->
					<td><select id="placa" name="placa" style="width: 100%;">
					<?php while($row_placa_info = mysqli_fetch_assoc($result_placa_info)):?>
					<option value="<?php echo $row_placa_info['id'];?>"><?php echo $row_placa_info['nome'];?></option>
					<?php endwhile;?>

					</select></td>
					<!-- -->
					<td><input type="date" name="data_instalacao"/></td>
					<td></td>
					<td></td>
					<td><button type="submit" name="add_placa" value="<?php echo $idtorre;?>"><img src="img/ok.png" width="30px" height="30px"/></button></td>
					</tr>
					</form>
			</tbody>
		</table>
  </div>
</div>



<?php else : ?>
    <p class="no-data">Acesso não permitido!</p>
<?php endif; ?>
 	<?php include('../../baixo.php'); ?>
    <script src="../../menu.js.php"></script>
    <?php include('../../rodape.php'); ?>

<script>
    function getBateriaInput() {
        // Prompt para pegar a entrada do usuário
        var informacao = prompt("Digite a Informação ou ignore deixando em branco:");
        var data_instalacao = prompt("Digite a data da instalação no formato YYYY-MM-DD ou ignore deixando em branco:");
        var data_remocao = prompt("Digite a data da remocao no formato YYYY-MM-DD ou ignore deixando em branco:");

         var regex = /^\d{4}-\d{2}-\d{2}$/; // Expressão regular para o formato YYYY-MM-DD
		// Defina o valor do input escondido com o valor do prompt
        if (informacao != "") {
            document.getElementById('informacao').value = informacao;
			 }
		if(data_instalacao != ""){
            document.getElementById('data_instalacao').value = data_instalacao;
			 }
		if(data_remocao != ""){
            document.getElementById('data_remocao').value = data_remocao;
		}

            // Submete o formulário
            document.getElementById('bateria_atualizar').submit();

    }



	
var btn = document.getElementById('btn_form');
var form = document.getElementById('my_form_edit');

btn.addEventListener('click', function() {
  if(form.style.display != 'block') {
    form.style.display = 'block';
    return;
  }
  form.style.display = 'none';
});



   // Função para abrir o popup
   function abrirPopup(id) {

            document.getElementById('formPopupAtualizaBat').style.display = 'block';
            document.getElementById('overlay').style.display = 'block';

			document.getElementById("idbateria").value = encodeURIComponent(id);
        }

        // Função para fechar o popup
        function fecharPopup() {
            document.getElementById('formPopupAtualizaBat').style.display = 'none';
            document.getElementById('overlay').style.display = 'none';
        }
</script>

</body>
</html>
